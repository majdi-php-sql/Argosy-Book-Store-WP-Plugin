jQuery(document).ready(function($) {
    $('.book-like-button').on('click', function(e) {
        e.preventDefault();
        var book_id = $(this).data('book-id');

        $.post(BookLibrary.ajaxurl, {
            action: 'book_like',
            book_id: book_id
        }, function(response) {
            if (response.success) {
                $('.book-likes-count[data-book-id="' + book_id + '"]').text(response.data.likes);
            }
        });
    });
});
