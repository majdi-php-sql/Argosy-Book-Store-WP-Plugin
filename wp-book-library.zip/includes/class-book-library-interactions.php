<?php
class Book_Library_Interactions {
    public static function register() {
        add_action('init', array(__CLASS__, 'enable_comments'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
        add_action('wp_ajax_nopriv_book_like', array(__CLASS__, 'handle_like'));
        add_action('wp_ajax_book_like', array(__CLASS__, 'handle_like'));
    }

    public static function enable_comments() {
        add_post_type_support('book', array('comments'));
    }

    public static function enqueue_scripts() {
        wp_enqueue_script('book-library-interactions', plugin_dir_url(__FILE__) . '../js/book-interactions.js', array('jquery'), null, true);
        wp_localize_script('book-library-interactions', 'BookLibrary', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
        ));
    }

    public static function handle_like() {
        if (!isset($_POST['book_id']) || !is_numeric($_POST['book_id'])) {
            wp_send_json_error();
        }

        $book_id = intval($_POST['book_id']);
        $likes = get_post_meta($book_id, '_book_likes', true);
        $likes = $likes ? intval($likes) : 0;
        $likes++;
        update_post_meta($book_id, '_book_likes', $likes);

        wp_send_json_success(array('likes' => $likes));
    }
}
?>
