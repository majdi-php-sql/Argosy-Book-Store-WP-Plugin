<?php
class Book_Library_Search {
    public static function register() {
        add_shortcode('book_search', array(__CLASS__, 'render_search_form'));
        add_action('pre_get_posts', array(__CLASS__, 'filter_search_results'));
    }

    public static function render_search_form() {
        ob_start();
        ?>
        <form role="search" method="get" id="searchform" action="<?php echo esc_url(home_url('/')); ?>">
            <div>
                <label for="s" class="screen-reader-text">Search for:</label>
                <input type="text" value="<?php echo get_search_query(); ?>" name="s" id="s" />
                <input type="hidden" name="post_type" value="book" />
                <input type="submit" id="searchsubmit" value="Search" />
            </div>
        </form>
        <?php
        return ob_get_clean();
    }

    public static function filter_search_results($query) {
        if (!is_admin() && $query->is_search() && $query->is_main_query() && isset($_GET['post_type']) && $_GET['post_type'] == 'book') {
            $query->set('post_type', 'book');
        }
    }
}
?>
