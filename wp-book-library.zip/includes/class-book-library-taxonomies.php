<?php
class Book_Library_Taxonomies {
    public static function register() {
        // Book Categories
        $labels = array(
            'name'              => 'Book Categories',
            'singular_name'     => 'Book Category',
            'search_items'      => 'Search Book Categories',
            'all_items'         => 'All Book Categories',
            'parent_item'       => 'Parent Book Category',
            'parent_item_colon' => 'Parent Book Category:',
            'edit_item'         => 'Edit Book Category',
            'update_item'       => 'Update Book Category',
            'add_new_item'      => 'Add New Book Category',
            'new_item_name'     => 'New Book Category Name',
            'menu_name'         => 'Book Categories',
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'book-category'),
        );

        register_taxonomy('book_category', array('book'), $args);

        // Book Sub-categories (can reuse $labels and $args with slight modifications)
        $labels = array(
            'name'              => 'Book Sub-categories',
            'singular_name'     => 'Book Sub-category',
            'search_items'      => 'Search Book Sub-categories',
            'all_items'         => 'All Book Sub-categories',
            'parent_item'       => 'Parent Book Sub-category',
            'parent_item_colon' => 'Parent Book Sub-category:',
            'edit_item'         => 'Edit Book Sub-category',
            'update_item'       => 'Update Book Sub-category',
            'add_new_item'      => 'Add New Book Sub-category',
            'new_item_name'     => 'New Book Sub-category Name',
            'menu_name'         => 'Book Sub-categories',
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'book-sub-category'),
        );

        register_taxonomy('book_sub_category', array('book'), $args);

        // Authors
        $labels = array(
            'name'              => 'Authors',
            'singular_name'     => 'Author',
            'search_items'      => 'Search Authors',
            'all_items'         => 'All Authors',
            'edit_item'         => 'Edit Author',
            'update_item'       => 'Update Author',
            'add_new_item'      => 'Add New Author',
            'new_item_name'     => 'New Author Name',
            'menu_name'         => 'Authors',
        );

        $args = array(
            'hierarchical'      => false,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'author'),
        );

        register_taxonomy('author', array('book'), $args);
    }
}
?>
