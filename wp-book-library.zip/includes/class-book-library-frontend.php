<?php
class Book_Library_Frontend {
    public static function register() {
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
        add_filter('template_include', array(__CLASS__, 'include_template'), 1);
    }

    public static function enqueue_scripts() {
        wp_enqueue_style('book-library-styles', plugin_dir_url(__FILE__) . '../css/front-end-styles.css');
    }

    public static function include_template($template_path) {
        if (get_post_type() == 'book') {
            if (is_single()) {
                if ($theme_file = locate_template(array('single-book.php'))) {
                    $template_path = $theme_file;
                } else {
                    $template_path = plugin_dir_path(__FILE__) . '../templates/single-book.php';
                }
            } elseif (is_archive()) {
                if ($theme_file = locate_template(array('archive-book.php'))) {
                    $template_path = $theme_file;
                } else {
                    $template_path = plugin_dir_path(__FILE__) . '../templates/archive-book.php';
                }
            }
        }
        return $template_path;
    }
}
?>
