<?php
class Book_Library_Metaboxes {
    public static function register() {
        add_action('add_meta_boxes', array(__CLASS__, 'add_meta_boxes'));
        add_action('save_post', array(__CLASS__, 'save_meta_boxes'));
    }

    public static function add_meta_boxes() {
        add_meta_box('book_details', 'Book Details', array(__CLASS__, 'render_meta_box'), 'book', 'normal', 'high');
    }

    public static function render_meta_box($post) {
        // Add nonce for security and authentication.
        wp_nonce_field('book_details_nonce_action', 'book_details_nonce');

        // Retrieve existing values from the database.
        $pdf_url = get_post_meta($post->ID, '_book_pdf', true);
        $description = get_post_meta($post->ID, '_book_description', true);
        $author = get_post_meta($post->ID, '_book_author', true);
        $publication_date = get_post_meta($post->ID, '_book_publication_date', true);

        echo '<p><label for="book_pdf">Upload PDF</label>';
        echo '<input type="file" id="book_pdf" name="book_pdf" value="' . esc_attr($pdf_url) . '" size="25" /></p>';

        echo '<p><label for="book_description">Description</label>';
        echo '<textarea id="book_description" name="book_description" rows="4" cols="50">' . esc_textarea($description) . '</textarea></p>';

        echo '<p><label for="book_author">Author</label>';
        echo '<input type="text" id="book_author" name="book_author" value="' . esc_attr($author) . '" size="25" /></p>';

        echo '<p><label for="book_publication_date">Publication Date</label>';
        echo '<input type="date" id="book_publication_date" name="book_publication_date" value="' . esc_attr($publication_date) . '" size="25" /></p>';
    }

    public static function save_meta_boxes($post_id) {
        // Check nonce for security.
        if (!isset($_POST['book_details_nonce']) || !wp_verify_nonce($_POST['book_details_nonce'], 'book_details_nonce_action')) {
            return;
        }

        // Check if not an autosave.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Save PDF URL.
        if (!empty($_FILES['book_pdf']['name'])) {
            $upload = wp_upload_bits($_FILES['book_pdf']['name'], null, file_get_contents($_FILES['book_pdf']['tmp_name']));
            if (isset($upload['error']) && $upload['error'] != 0) {
                wp_die('There was an error uploading your file. The error is: ' . $upload['error']);
            } else {
                update_post_meta($post_id, '_book_pdf', $upload['url']);
            }
        }

        // Save other fields.
        if (isset($_POST['book_description'])) {
            update_post_meta($post_id, '_book_description', sanitize_text_field($_POST['book_description']));
        }
        if (isset($_POST['book_author'])) {
            update_post_meta($post_id, '_book_author', sanitize_text_field($_POST['book_author']));
        }
        if (isset($_POST['book_publication_date'])) {
            update_post_meta($post_id, '_book_publication_date', sanitize_text_field($_POST['book_publication_date']));
        }
    }
}
?>
