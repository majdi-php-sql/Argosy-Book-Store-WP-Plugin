<?php
get_header();

if (have_posts()) :
    while (have_posts()) : the_post();
        $pdf_url = get_post_meta(get_the_ID(), '_book_pdf', true);
        $description = get_post_meta(get_the_ID(), '_book_description', true);
        $author = get_post_meta(get_the_ID(), '_book_author', true);
        $publication_date = get_post_meta(get_the_ID(), '_book_publication_date', true);
        $likes = get_post_meta(get_the_ID(), '_book_likes', true);
        $likes = $likes ? intval($likes) : 0;
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
            </header>
            <div class="entry-content">
                <?php if ($pdf_url) : ?>
                    <p><a href="<?php echo esc_url($pdf_url); ?>">Download PDF</a></p>
                <?php endif; ?>
                <?php if ($description) : ?>
                    <p><?php echo esc_html($description); ?></p>
                <?php endif; ?>
                <?php if ($author) : ?>
                    <p><strong>Author:</strong> <?php echo esc_html($author); ?></p>
                <?php endif; ?>
                <?php if ($publication_date) : ?>
                    <p><strong>Publication Date:</strong> <?php echo esc_html($publication_date); ?></p>
                <?php endif; ?>
                <p>
                    <button class="book-like-button" data-book-id="<?php the_ID(); ?>">Like</button>
                    <span class="book-likes-count" data-book-id="<?php the_ID(); ?>"><?php echo $likes; ?></span> Likes
                </p>
            </div>
        </article>
        <?php
        comments_template();
    endwhile;
endif;

get_footer();
?>
