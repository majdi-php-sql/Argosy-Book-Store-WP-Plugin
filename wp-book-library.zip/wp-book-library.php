<?php
/*
Plugin Name: Argosy Book Store
Description: This plugin created to support Argosy Book Store WP website.
Version: 1.0
Author: Majdi M. S. Awad
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Include necessary files
require_once plugin_dir_path(__FILE__) . 'includes/class-book-library-cpt.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-book-library-taxonomies.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-book-library-metaboxes.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-book-library-frontend.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-book-library-search.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-book-library-interactions.php';

// Initialize the plugin
function wp_book_library_init() {
    Book_Library_CPT::register();
    Book_Library_Taxonomies::register();
    Book_Library_Metaboxes::register();
    Book_Library_Frontend::register();
    Book_Library_Search::register();
    Book_Library_Interactions::register();
}
add_action('init', 'wp_book_library_init');

// Enqueue admin scripts and styles
function wp_book_library_admin_scripts() {
    wp_enqueue_style('wp-book-library-admin-styles', plugin_dir_url(__FILE__) . 'css/admin-styles.css');
    wp_enqueue_script('wp-book-library-admin-scripts', plugin_dir_url(__FILE__) . 'js/admin-scripts.js', array('jquery'), false, true);
}
add_action('admin_enqueue_scripts', 'wp_book_library_admin_scripts');

?>
